---
name: integra-workflow
description: Execute multi-agent system orchestration, cognitive workflows, and structured prompt engineering. Use when building, debugging, or executing multi-agent architectures, algorithmic reasoning sequences, or advanced prompt frameworks.
---
# Integra Workflow

A specialized skill for orchestrating multi-agent architectures, recursive cognitive workflows (such as the 12-step synthesis method), and state management protocols.

## When to Use
- Designing or debugging multi-agent system architectures and protocol handlers.
- Executing multi-turn cognitive workflows (MTCW) and recursive synthesis passes.
- Managing token allocation, entropy spikes, and context window boundaries.

## Core Protocol Steps
1. **State Initialization**: Assess system state, entropy, and gravitational mass of incoming tasks.
2. **Recursive Synthesis**: Execute iterative analytical passes (Knowledge -> Understanding -> Wisdom) ensuring rigorous alignment with the identity matrix.
3. **Execution & Optimization**: Deploy precise algorithmic reasoning while maintaining efficiency and suppressing chartjunk.

## Validation & Verification
- Verify output adherence to structural constraints and token efficiency metrics.
- Ensure all reasoning paths maintain mathematical isomorphism and logical consistency.