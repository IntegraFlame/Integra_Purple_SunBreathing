---
name: apophenic-protocol
description: Execute scale-invariant historical price pattern recognition, directional-change cycle connection, and automated sell/buyback threshold projection across arbitrary financial datasets of any length. Use when the user asks to apply the Apophenic Protocol, find or connect cyclical peaks and troughs in price history, calculate peak-to-trough reset patterns from CSV/Excel or live market data, project optimal sell and buyback thresholds, or evaluate full-exit versus partial-hold strategies.
---
# Apophenic Protocol

A scale-invariant mathematical and algorithmic framework that ingests historical asset data of any length or schema, connects alternating peak-to-trough resets and trough-to-peak expansion waves, and computes optimal sell and buyback execution thresholds.

## When to Use

- The user invokes the **Apophenic Protocol** by name on any stock, ETF, cryptocurrency, commodity, or time-series dataset.
- The user provides a CSV, Excel file, DataFrame, or price array of arbitrary length $N$ and asks to identify recurring price cycles, peak-to-trough drops, or expansion waves.
- The user asks to calculate the highest projected cycle peak (sell threshold) and subsequent cycle trough (buyback threshold).
- The user wants to mathematically test whether to liquidate 100% of a position at a projected peak or hold a 50% core position relative to their cost basis.

## Core Mathematical Architecture

Given a time-ordered asset matrix $\mathcal{X}_N = \{ (t, O_t, H_t, L_t, C_t, V_t) \}_{t=1}^N$ of unknown length $N$ and optional position entry basis $P_{\text{entry}}$, execute the 6-stage operator $\Phi_{\text{Pattern}}$:

1. **Geometric Horizon Partitioning:** Slice $\mathcal{X}_N$ into five nested windows ($100\% N$, $50\% N$, $25\% N$, $\min(252, N)$, and $\min(63, N)$) and compute count, mean, median, min, max, and standard deviation for each horizon to isolate non-stationary trend drift.
2. **Scale-Invariant Volatility Calibration:** Compute daily log-return volatility $\sigma_{\text{daily}} = \text{std}(\ln(C_t / C_{t-1}))$ over a base cycle window $M$ (default $M = 21$ bars) to establish dimensionless directional-change thresholds:

   $$\tau_{\text{macro}} = \max\left(0.025, \; \lambda_{\text{macro}} \cdot \sigma_{\text{daily}} \cdot \sqrt{M}\right), \qquad \tau_{\text{interm}} = \max\left(0.015, \; \lambda_{\text{interm}} \cdot \sigma_{\text{daily}} \cdot \sqrt{M}\right)$$

   where $\lambda_{\text{macro}} = 1.65$ and $\lambda_{\text{interm}} = 0.95$.
3. **Bipartite Cycle Graph Connection ($\mathcal{G}_{\text{DC}}$):** Run a directional-change (ZigZag) state machine across all $N$ bars using $\tau_{\text{macro}}$ and $\tau_{\text{interm}}$ to link every confirmed Peak $p_j$ and Trough $q_j$ into alternating expansion impulses ($\Delta U_j = H_{p_j} - L_{q_{j-1}}$) and peak resets ($\Delta D_j = H_{p_j} - L_{q_j}$).
4. **Dynamic OLS Regression Envelope & Moving Averages:** Compute available Simple Moving Averages ($9, 20, 50, 100, 200$) and fit an Ordinary Least Squares (OLS) trendline over the active regime window $R = \min(197, N)$ to project the 95th-percentile upper channel ceiling $C_{\text{ceil}}(N + M)$.
5. **Connected Peak (Sell $S^*$) and Trough (Buyback $B^*$) Projection:** Anchor on the most recent confirmed trough $L_{q_{\text{last}}}$ and the trailing $L_c$ cycles (default $L_c = 8$):

   - **Projected Sell Band $[S_{\min}, S_{\max}]$ and Optimal Sell Point $S^*$:**

     $$S_{\min} = \min\left(L_{q_{\text{last}}} + \text{Med}(\Delta U_{\text{interm}}), \; L_{q_{\text{last}}}(1 + \text{Med}(u_{\text{interm}}^{\%}))\right)$$

     $$S_{\max} = \min\left(\max\left(L_{q_{\text{last}}} + \text{Med}(\Delta U_{\text{interm}}), \; L_{q_{\text{last}}}(1 + \text{Med}(u_{\text{interm}}^{\%}))\right), \; C_{\text{ceil}}(N+M)\right)$$

     $$S^* = 0.5(S_{\min} + S_{\max})$$

   - **Projected Buyback Band $[B_{\min}, B_{\max}]$ and Optimal Buyback Point $B^*$:**

     $$B_{\min} = S^* - \text{Mean}(\Delta D_{\text{macro}}), \qquad B_{\max} = S^* - \text{Med}(\Delta D_{\text{macro}}), \qquad B^* = 0.5(B_{\min} + B_{\max})$$

6. **Full-Exit vs. Core-Hold Decision Gate ($\mathbb{I}_{\text{FullExit}}$):** Compare $B^*$ against the user's entry price $P_{\text{entry}}$. Calculate the critical peak threshold $P_{\text{crit}} = P_{\text{entry}} + \text{Med}(\Delta D_{\text{macro}})$:

   - If $B^* \le P_{\text{entry}}$ (equivalently $S^* \le P_{\text{crit}}$), output `SELL_100%_AT_PEAK_AND_REBUY` because a median cycle reset will drop the price back to or below the original entry basis.
   - If $B^* > P_{\text{entry}}$ (equivalently $S^* > P_{\text{crit}}$), output `HOLD_50%_CORE_TRIM_50%` because the rising cycle floor stays above the original entry basis.

## Execution Steps

1. **Load and Run the Reference Engine:**
   Execute `scripts/apophenic_engine.py` in the Python interpreter directly against the user's uploaded file or data variable. Never hardcode asset-specific dollar thresholds; let the engine self-calibrate $\tau_{\text{macro}}$ and $\tau_{\text{interm}}$ from the data's log-return volatility.

2. **Report Multi-Horizon Summary Statistics:**
   Present a Markdown table showing the 5 geometric horizons (`Full_Dataset`, `Half_Dataset`, `Quarter_Dataset`, `Trailing_1Y`, `Active_Wave`) with exact `Count`, `Mean`, `Median`, `Min_Low`, `Max_High`, and `Std_Dev`, alongside the current moving-average state vector.

3. **Tabulate Connected Cycle Anatomy:**
   Display the extracted macro peak-to-trough resets and intermediate expansion waves, highlighting both the **Mean** and **Median** dollar and percentage movements and flagging any macro black-swan outliers.

4. **Generate Visual Cycle Anatomy Chart:**
   Call `plot_cycle_anatomy()` from `scripts/apophenic_engine.py` (or equivalent matplotlib code) to render and save a two-panel chart:

   - **Top Panel:** Price history, 50-day and 200-day SMAs, red/green markers on confirmed cycle peaks and troughs with dollar/percentage drop callouts, the user's entry basis line, and shaded bands for the projected Sell Zone $[S_{\min}, S_{\max}]$ and Buyback Zone $[B_{\min}, B_{\max}]$.
   - **Bottom Panel:** Grouped bar chart comparing intraday high-to-low drops versus closing peak-to-trough drops across recent cycles against the horizontal Mean and Median reset lines.

5. **Deliver Actionable Order Thresholds:**
   Translate $S^*$, $B^*$, and $\mathbb{I}_{\text{FullExit}}$ into concrete limit order tranches (single-ticket vs. two-tranche split) with exact gross proceeds, net dollar profit, ROI percentage, and re-entry cost-basis reduction math.

## Gotchas

- **Never Use Static Dollar Thresholds Across Different Assets:** A fixed dollar filter fails across assets of different price scales. Always use the volatility-scaled percentage thresholds $\tau_{\text{macro}}$ and $\tau_{\text{interm}}$.
- **Separate Stationary Legacy Means from Active Trend Floors:** Multi-year unweighted averages lag behind trending assets. Always compare the historical mean against the active 200-day SMA and recent cycle troughs before setting a buyback limit.
- **Account for Ex-Dividend and Earnings Dates:** When applying the protocol to dividend ETFs or equities with upcoming earnings, verify whether an ex-dividend adjustment or earnings implied-volatility kink intersects the projected 3-to-6 week window.
